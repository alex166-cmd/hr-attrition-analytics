
-- One fact table for employees, one small lookup for the 1-4 rating scales.

DROP TABLE IF EXISTS employees;
CREATE TABLE employees (
    employee_id                 INTEGER PRIMARY KEY,
    age                         INTEGER NOT NULL,
    attrition                   TEXT    NOT NULL CHECK (attrition IN ('Yes','No')),
    business_travel             TEXT,
    department                  TEXT    NOT NULL,
    distance_from_home          INTEGER,
    education                   INTEGER,
    education_field             TEXT,
    env_satisfaction            INTEGER,
    gender                      TEXT,
    job_involvement             INTEGER,
    job_level                   INTEGER NOT NULL,
    job_role                    TEXT    NOT NULL,
    job_satisfaction            INTEGER,
    marital_status              TEXT,
    monthly_income              INTEGER NOT NULL,
    num_companies_worked        INTEGER,
    overtime                    TEXT,
    percent_salary_hike         INTEGER,
    performance_rating          INTEGER,
    relationship_satisfaction   INTEGER,
    stock_option_level          INTEGER,
    total_working_years         INTEGER,
    training_times_last_year    INTEGER,
    work_life_balance           INTEGER,
    years_at_company            INTEGER,
    years_in_current_role       INTEGER,
    years_since_last_promotion  INTEGER,
    years_with_curr_manager     INTEGER,
    attrition_flag              INTEGER NOT NULL,
    overtime_flag               INTEGER NOT NULL,
    age_band                    TEXT,
    tenure_band                 TEXT,
    promotion_gap_band          TEXT,
    commute_band                TEXT
);

DROP TABLE IF EXISTS rating_scale;
CREATE TABLE rating_scale (
    score  INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);
INSERT INTO rating_scale VALUES (1,'Low'),(2,'Medium'),(3,'High'),(4,'Very high');

CREATE INDEX idx_emp_dept   ON employees(department);
CREATE INDEX idx_emp_role   ON employees(job_role);
CREATE INDEX idx_emp_attr   ON employees(attrition_flag);
