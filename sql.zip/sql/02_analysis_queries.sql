
-- Each query starts with a "-- name:" line. The Python runner (02_build_database.py)
-- reads that name, runs the query and saves the result as outputs/query_results/<name>.csv

-- name: q01_headline_kpis
SELECT COUNT(*)                                        AS headcount,
       SUM(attrition_flag)                             AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1) AS attrition_rate_pct,
       ROUND(AVG(CASE WHEN attrition_flag = 1 THEN years_at_company END), 1) AS avg_tenure_of_leavers,
       ROUND(AVG(CASE WHEN attrition_flag = 0 THEN years_at_company END), 1) AS avg_tenure_of_stayers,
       ROUND(AVG(monthly_income), 0)                   AS avg_monthly_income
FROM employees;

-- name: q02_attrition_by_department
SELECT department,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct,
       ROUND(100.0 * SUM(attrition_flag) /
             (SELECT SUM(attrition_flag) FROM employees), 1) AS share_of_all_leavers_pct
FROM employees
GROUP BY department
ORDER BY attrition_rate_pct DESC;

-- name: q03_attrition_by_job_role
-- RANK() is a window function: it orders roles by rate without collapsing rows.
SELECT job_role,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct,
       RANK() OVER (ORDER BY 1.0 * SUM(attrition_flag) / COUNT(*) DESC) AS risk_rank
FROM employees
GROUP BY job_role
ORDER BY risk_rank;

-- name: q04_overtime_effect
SELECT overtime,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM employees), 1) AS share_of_workforce_pct,
       ROUND(100.0 * SUM(attrition_flag) /
             (SELECT SUM(attrition_flag) FROM employees), 1)         AS share_of_leavers_pct
FROM employees
GROUP BY overtime;

-- name: q05_overtime_by_job_level
SELECT job_level,
       overtime,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct
FROM employees
GROUP BY job_level, overtime
ORDER BY job_level, overtime;

-- name: q06_attrition_by_tenure
SELECT tenure_band,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct
FROM employees
GROUP BY tenure_band
ORDER BY MIN(years_at_company);

-- name: q07_pay_position
-- Compa-ratio = an employee's pay divided by the average pay at the same job level.
-- A value below 1 means paid under the level average. A CTE keeps the logic readable.
WITH level_avg AS (
    SELECT job_level, AVG(monthly_income) AS avg_income
    FROM employees
    GROUP BY job_level
),
banded AS (
    SELECT e.employee_id,
           e.attrition_flag,
           e.monthly_income * 1.0 / l.avg_income AS compa_ratio,
           CASE
               WHEN e.monthly_income * 1.0 / l.avg_income < 0.85 THEN '1. Below 85%'
               WHEN e.monthly_income * 1.0 / l.avg_income < 1.00 THEN '2. 85% to 99%'
               WHEN e.monthly_income * 1.0 / l.avg_income < 1.15 THEN '3. 100% to 114%'
               ELSE '4. 115% and above'
           END AS pay_position
    FROM employees e
    JOIN level_avg l ON l.job_level = e.job_level
)
SELECT pay_position,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct
FROM banded
GROUP BY pay_position
ORDER BY pay_position;

-- name: q08_satisfaction_and_work_life_balance
SELECT 'Job satisfaction' AS measure, r.label AS rating, COUNT(*) AS headcount,
       ROUND(100.0 * SUM(e.attrition_flag) / COUNT(*), 1) AS attrition_rate_pct
FROM employees e JOIN rating_scale r ON r.score = e.job_satisfaction
GROUP BY r.score, r.label
UNION ALL
SELECT 'Work-life balance', r.label, COUNT(*),
       ROUND(100.0 * SUM(e.attrition_flag) / COUNT(*), 1)
FROM employees e JOIN rating_scale r ON r.score = e.work_life_balance
GROUP BY r.score, r.label
UNION ALL
SELECT 'Environment satisfaction', r.label, COUNT(*),
       ROUND(100.0 * SUM(e.attrition_flag) / COUNT(*), 1)
FROM employees e JOIN rating_scale r ON r.score = e.env_satisfaction
GROUP BY r.score, r.label;

-- name: q09_promotion_gap_and_stock_options
SELECT 'Years since last promotion' AS measure, promotion_gap_band AS grp,
       COUNT(*) AS headcount,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1) AS attrition_rate_pct
FROM employees GROUP BY promotion_gap_band
UNION ALL
SELECT 'Stock option level', CAST(stock_option_level AS TEXT), COUNT(*),
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)
FROM employees GROUP BY stock_option_level
UNION ALL
SELECT 'Business travel', business_travel, COUNT(*),
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)
FROM employees GROUP BY business_travel
UNION ALL
SELECT 'Marital status', marital_status, COUNT(*),
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)
FROM employees GROUP BY marital_status;

-- name: q10_cost_of_attrition_by_department
-- The replacement cost percentage is an assumption. Change it in the params CTE.
WITH params AS (SELECT 0.50 AS replacement_cost_pct)
SELECT e.department,
       SUM(e.attrition_flag)                                        AS leavers,
       ROUND(AVG(CASE WHEN e.attrition_flag = 1 THEN e.monthly_income * 12 END), 0) AS avg_annual_salary_of_leavers,
       ROUND(SUM(CASE WHEN e.attrition_flag = 1
                      THEN e.monthly_income * 12 * p.replacement_cost_pct END), 0)  AS estimated_replacement_cost
FROM employees e, params p
GROUP BY e.department
ORDER BY estimated_replacement_cost DESC;

-- name: q11_high_risk_segments
-- Segments of at least 30 people where attrition is well above the company rate.
SELECT job_level,
       overtime,
       tenure_band,
       COUNT(*)                                          AS headcount,
       SUM(attrition_flag)                               AS leavers,
       ROUND(100.0 * SUM(attrition_flag) / COUNT(*), 1)  AS attrition_rate_pct
FROM employees
GROUP BY job_level, overtime, tenure_band
HAVING COUNT(*) >= 30
   AND 1.0 * SUM(attrition_flag) / COUNT(*) > 0.25
ORDER BY attrition_rate_pct DESC;

-- name: q12_pay_gap_between_leavers_and_stayers
-- Window function again: compare each role's leavers with its stayers.
SELECT job_role,
       ROUND(AVG(CASE WHEN attrition_flag = 1 THEN monthly_income END), 0) AS avg_income_leavers,
       ROUND(AVG(CASE WHEN attrition_flag = 0 THEN monthly_income END), 0) AS avg_income_stayers,
       ROUND(100.0 * (AVG(CASE WHEN attrition_flag = 1 THEN monthly_income END) /
                      AVG(CASE WHEN attrition_flag = 0 THEN monthly_income END) - 1), 1) AS leavers_vs_stayers_pct
FROM employees
GROUP BY job_role
ORDER BY leavers_vs_stayers_pct;
