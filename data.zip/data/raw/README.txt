IBM HR Analytics Employee Attrition & Performance dataset.
Kaggle: search "IBM HR Analytics Employee Attrition & Performance" (file WA_Fn-UseC_-HR-Employee-Attrition.csv).
Same data on GitHub: https://raw.githubusercontent.com/IBM/employee-attrition-aif360/master/data/emp_attrition.csv
Save the file in this folder as IBM_HR_Attrition.csv.
